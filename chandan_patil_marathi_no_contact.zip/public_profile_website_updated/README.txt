Chandan Patil Marathi profile website.

This version removes the visitor contact form and MongoDB/PyMongo contact storage.
The website does not collect visitor name, email, mobile number, or message.
User-supplied photos and video are included in static/images.

Run: python app.py
Open: http://127.0.0.1:5000
